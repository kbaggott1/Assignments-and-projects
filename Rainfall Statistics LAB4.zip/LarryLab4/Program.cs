﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;

namespace LarryLab4
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string choice = "";
            bool flag = true;
            bool error;
            string avgRainfall = "No Data to Compute";

            while (flag)
            {
                error = false;
                Clear();
                WriteLine("MAIN MENU\n\n1.\tRainfall Statistics\n2.\tCharge Account Validation\n3.\tExit");
                WriteLine("\nEnter your choice");
                WriteLine("\nAverage Monthly Rain: " + avgRainfall);

                choice = ReadLine();
                switch (choice)
                {
                    case "1":
                        avgRainfall = RainfallStatistics();
                        break;

                    case "2":
                        ChargeACCVal();
                        break;

                    case "3":
                        flag = false;
                        break;

                    default:
                        error = true;
                        Clear();
                        break;

                }
                if (error == true)
                {
                    WriteLine("Error, Please select 1 of 3 options. Press enter to reselect.");
                    ReadLine();
                }

                else if (flag == true)
                {
                    WriteLine("\nPress enter to return to main menu");
                    ReadLine();
                }

            }

        }
      
        static string RainfallStatistics()
        {           
            int[] rainfalls = new int[12];
            string avgRainFall;
            Clear();

            int response = 0;
            int counter = 0;
            foreach (int c in rainfalls)
            {
                WriteLine($"How many rainfalls were there in {monthtowords(counter)}");

                response = checkInput(response);

                rainfalls[counter] = response;
                counter++;
                Clear();
            }

            DisplayRainfalls(rainfalls);
            avgRainFall = AverageMonthly(rainfalls);
            MaxRain(rainfalls);
            MinRain(rainfalls);
            return avgRainFall;
            
        }


        static void DisplayRainfalls(int[] rainfalls)
        {
            WriteLine($"The total amount of times it rained this year was {rainfalls.Sum()} times.");
        }

        static string AverageMonthly(int[] rainfalls)
        {
            string avgrain;
            WriteLine($"The average monthly rainfall was {rainfalls.Average()}");
            avgrain = rainfalls.Average().ToString();
            return avgrain;            
        }

        static void MaxRain(int[] rainfalls)
        {
            int max = rainfalls.Max();
            string maxText = "most";
            multicheck(rainfalls, max, maxText);
        }

        static void MinRain(int[] rainfalls) 
        {
            int min = rainfalls.Min();
            string minText = "least";
            multicheck(rainfalls, min, minText);            
        }

        static string monthtowords(int i)
        {
            switch (i)
            {
                case 0:
                    return "January";
                case 1:
                    return "February";
                case 2:
                    return "March";
                case 3:
                    return "April";
                case 4:
                    return "May";
                case 5:
                    return "June";
                case 6:
                    return "July";
                case 7:
                    return "August";
                case 8:
                    return "September";
                case 9:
                    return "October";
                case 10:
                    return "November";
                case 11:
                    return "December";
                default:
                    return "";
                
            }
        }

        static void ChargeACCVal()
        {
            Clear();
            int response = 0;
            int[] acc =
            {
                5658845, 4520125, 7895122, 8777541, 8451277, 1302850,
                8080152, 4562555, 5552012, 5050552, 7825877, 1250255,
                1005231, 6545231, 3852085, 7576651, 7881200, 4581002
            };

            WriteLine("Enter your charge account number");
            response = checkInput(response);

            Clear();

            if (checkInputACC(response, acc) == true)
                WriteLine("Charge Account Number is valid");
            else
                WriteLine($"The Charge Account Number: \"{response}\" is an invalid account.");
            
            
        }

        static bool checkInputACC(int numcheck, int[] acc)
        {
            foreach (int c in acc)
            {
                if (numcheck == c)
                {
                    return true;
                }                
                    
            }
            return false;
        }

        static void multicheck(int[] rainfalls, int MinOrMax, string TextMinOrMax)
        {
            List<int> tempIndexes = new List<int> { };
            int counter = 0;         

            foreach (int c in rainfalls)
            {
                if (c == MinOrMax)
                {
                    tempIndexes.Add(Array.IndexOf(rainfalls, MinOrMax));
                    rainfalls[Array.IndexOf(rainfalls, MinOrMax)] = (MinOrMax + 1); //(MinOrMax + 1) This is so it doesn't re-add the same index
                }

            }

            if (tempIndexes.Count > 1)
            {
                WriteLine($"\nThe {TextMinOrMax} amount of times it rained this year in a month was {MinOrMax} and it was a tie between:\n ");
                foreach (int c in tempIndexes)
                {
                    ForegroundColor = ConsoleColor.Cyan;
                    WriteLine(monthtowords(tempIndexes[counter]));
                    counter++;
                }
                ForegroundColor = ConsoleColor.White;
            }
            else
                WriteLine($"\nThe {TextMinOrMax} amount of times it rained in a year was in {monthtowords(tempIndexes[0])} and it rained {MinOrMax} times.");

        }

        static int checkInput(int numtocheck)
        {
            while (!(int.TryParse(ReadLine(), out numtocheck)))
            {
                WriteLine("Invalid Input");
            }
            return numtocheck;
        }


    }
}
