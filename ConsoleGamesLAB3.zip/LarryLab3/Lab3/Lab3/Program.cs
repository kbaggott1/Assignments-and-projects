﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
namespace Lab3
{
    class Program
    {


        static void Main(string[] args)
        {
            MainMenu();
        }


        private static void MainMenu()
        {
            bool flag = true;
            do
            {
                Clear();

                WriteLine("1. Area of rectangles");
                WriteLine("2. Biggest number");
                WriteLine("3. Valid points");
                WriteLine("4. Dollar gamme");
                WriteLine("5. Oldest person");
                WriteLine("6. Hi Lo game");
                ForegroundColor = ConsoleColor.Red;
                WriteLine("7. Quit the menu\n");
                ForegroundColor = ConsoleColor.White;
                WriteLine("\nPlease Enter a Choice");



                switch (ReadLine())
                {
                    case "1":
                        AreaOfRectangles();
                        break;

                    case "2":
                        BiggestNumber();
                        break; 

                    case "3":
                        ValidPoints();
                        break;

                    case "4":
                        DollarGame();
                        break;

                    case "5":
                        OldestPerson();
                        break;

                    case "6":
                        HiLoGame();
                        break;

                    case "7":
                        flag = false;
                        break;

                    default:
                        MainMenu();
                        return;
                }

                if (flag != false) //for case 7 to skip over
                {
                    ForegroundColor = ConsoleColor.Green;
                    WriteLine("\n\nPress enter to return to the main menu");
                    ForegroundColor = ConsoleColor.White;
                    ReadLine();
                }


            } while (flag);            
           
                       
        }

        public static void AreaOfRectangles()
        {
            float length1; 
            float height1; 
            float area1;

            float length2; 
            float height2; 
            float area2;
            int response = 0;
            Clear();

            // area for rectangle 1
            Write("What is the length of the first rectangle? ");
            length1 = checknum(response);

            Write("\nWhat is the height of the first rectangle? ");
            height1 = checknum(response);

            area1 = length1 * height1;
            Clear();

            //area for rectangle2
            Write("What is the length of the second rectangle? ");

            length2 = checknum(response);

            Write("\nWhat is the height of the second rectangle? ");
            height2 = checknum(response);

            area2 = length2 * height2;
            Clear();

            //final output
            WriteLine($"Area of the first rectangle: \t{area1}");
            WriteLine($"Area of the second rectangle: \t{area2}\n\n");

            if (area1 > area2)
            {
                WriteLine("The area of the first rectangle is larger.");
            }
            else
            {
                if (area1 == area2)
                {
                    WriteLine($"Both rectangles have the same area.");
                }
                else
                {
                    WriteLine("The area of the second rectangle is larger.");
                }
                
            }


        }

        public static void BiggestNumber()
        {
            int[] num = new int[3];
            int response = 0;
            Clear();

            //num1
            Write("Please enter the first number between 1 and 100. ");

            num[0] = checknum(response);

            while (num[0] > 100 || num[0] < 1)
            {
                Write("\nThat isn't between 1 and 100. Please try again. ");

                num[0] = checknum(response);
            }
            Clear();

            //num2
            Write("Please enter the second number between 1 and 100. ");

            num[1] = checknum(response);

            while (num[1] > 100 || num[1] < 1)
            {
                Write("\nThat isn't between 1 and 100. Please try again. ");

                num[1] = checknum(response);
            }
            Clear();

            //num3
            Write("Please enter the third number between 1 and 100. ");

            num[2] = checknum(response);

            while (num[2] > 100 || num[2] < 1)
            {
                Write("\nThat isn't between 1 and 100. Please try again. ");

                num[2] = checknum(response);
            }
            Clear();

            //final output
            WriteLine($"first number:\t{num[0]}");
            WriteLine($"second number:\t{num[1]}");
            WriteLine($"third number:\t{num[2]}");
            WriteLine($"\nThe biggest number is {num.Max()}");

          
        }

        public static void ValidPoints()
        {
            int points = 0;
            int totalPoints = 0;
            int pointCounter = 0;
            const int min = 9, max = 51;
            int response = 0;
            bool flag = true; 

            Clear();

            WriteLine("Type 100 to stop playing.\n");

            while (flag)
            {
               

                Write($"\nWrite a number between {min} and {max}. ");

                points = checknum(response);


                if (points == 100)
                {
                    flag = false;
                }
                else
                {
                    if (points < 9 || points > 51)
                    {
                        Clear();
                        Write("Type 100 to stop playing.");
                        ForegroundColor = ConsoleColor.Red;
                        Write("\tInvalid points.\n");
                        ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        pointCounter++;
                        totalPoints += points;
                        Clear();
                        Write($"Type 100 to stop playing.");
                        ForegroundColor = ConsoleColor.Green;
                        Write($"\tValid points. x{pointCounter}\n");
                        ForegroundColor = ConsoleColor.White;
                    }
                    
                }

                
            }

            //final output
            Clear();
            WriteLine($"Number of valid points entered: {pointCounter}");
            WriteLine($"\nTotal points: {totalPoints}");


        }

        public static void DollarGame()
        {
            int pennies, nickels, dimes, quarters;
            float fPennies, fNickels, fDimes, fQuarters;
            float total;
            int attempts = 0;
            int response = 0;


            do
            {
                Clear();
                attempts++;

                //pennies
                Write("How many pennies? ");

                pennies = checknum(response);

                fPennies = (float)pennies;
                fPennies = fPennies * 0.01f;

                //nickels
                Write("\nHow many nickels? ");

                nickels = checknum(response);

                fNickels = (float)nickels;
                fNickels = fNickels * 0.05f;

                //dimes
                Write("\nHow many dimes? ");

                dimes = checknum(response);

                fDimes = (float)dimes;
                fDimes = fDimes * 0.10f;

                //quarters
                Write("\nHow many quarters? ");

                quarters = checknum(response);

                fQuarters = (float)quarters;
                fQuarters = fQuarters * 0.25f;

                //total
                total = fPennies + fNickels + fDimes + fQuarters;

                //final output
                Clear();

                if (total < 1)
                {
                    WriteLine($"You entered a total of {total.ToString("C2")}. You were under by ${Math.Round(1f - total, 2)}");
                    WriteLine("\nPress enter to retry.");
                    ReadLine();
                }
                else
                {
                    if (total > 1)
                    {
                        WriteLine($"You entered a total of {total.ToString("C2")}. You were over by ${Math.Round(total - 1f, 2)}");
                        WriteLine("\nPress enter to retry.");
                        ReadLine();
                        
                        
                    }
                    else
                    {
                        Write($"\nCongratulations! It took you ");

                        if (attempts == 1)
                        {
                            Write("1 turn to win!");
                        }
                        else
                        {
                            Write($"{attempts} turns to win!");
                        }
                    }
                }

            } while (total != 1.00f);


        }

        public static void OldestPerson()
        {
            ArrayList names = new ArrayList();
            List<int> ages = new List<int>();

            int age;
            string name = "";
            bool flag = true;
            int response = 0;


            Clear();

            do
            {
                ForegroundColor = ConsoleColor.Red;
                WriteLine("type \"end\" to stop playing\n");
                ForegroundColor = ConsoleColor.White;


                Write("\nPlease enter a name. ");

                checkName(ref name);                            
                names.Add(name);
                
                
                if (names.Contains("end"))
                {
                    Clear();
                    break;                    
                }

                
               Write($"\nPlease enter {name}'s age. ");

                age = checknum(response);
                while (age < 0)
                {
                    Write("That age isn't possible please try again. ");
                    age = checknum(response);
                }

                ages.Add(age);
                

                Clear();

            } while (flag);

            //I need to output which name goes with the oldest age
            WriteLine($"The oldest person is {names[ages.IndexOf(ages.Max())]} and they're {ages.Max()} years old.");


        }

        public static void HiLoGame()
        {
            int guess, min, max;
            int numberToGuess;
            int countGuesses = 0;
            int response = 0;

            Random dice = new Random();

            bool flag = true;

            Clear();

            Write("Between what two numbers do you want to guess?\n\n");
            Write("Min: ");

            min = checknum(response);

            Write("Max: ");

            max = checknum(response);

            numberToGuess = dice.Next(min, max);


            Write("Guess the number. ");
            do
            {
                
                countGuesses++;


                guess = checknum(response);
                

                if (guess > numberToGuess)
                {
                    Clear();
                    Write($"Min: {min}");
                    Write($"\nMax: {max}\n");
                    Write($"\nThe number is lower than {guess}. Try again. ");                    
                }
                else
                {
                    if (guess < numberToGuess)
                    {
                        Clear();
                        Write($"Min: {min}");
                        Write($"\nMax: {max}\n");
                        Write($"\nThe number is higher than {guess}. Try again. ");
                    }
                    else
                    {
                        Clear();
                        Write($"You got it! The number was {numberToGuess} and it took you ");

                        if (countGuesses == 1)
                            Write("1 guess.");
                        else
                            Write($"{countGuesses} guesses.");

                        flag = false;
                    }
                }

            } while (flag);


        }



        public static int checknum(int response)
        {
           
            while (!(int.TryParse((ReadLine()), out response)))
            {
                Write("\nInvalid input. ");
            }
            return response;
        }

        public static void checkName(ref string name)
        {

            bool validName = false;
            name = ReadLine();
            
            while (!validName)
            {

                foreach (char c in name)
                {
                    if (Convert.ToString(c).All(char.IsLetter))
                    {
                        validName = true;

                    }
                    else
                    {
                        Write("\nThat is not a valid name. Try again. ");
                        name = ReadLine();
                        validName = false;
                        break;
                    }
                }
                

            }

            
        }

    }
}

